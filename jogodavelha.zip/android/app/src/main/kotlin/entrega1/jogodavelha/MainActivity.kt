package entrega1.jogodavelha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
